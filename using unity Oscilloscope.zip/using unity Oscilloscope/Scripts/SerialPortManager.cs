﻿using UnityEngine ;
using System . IO . Ports ;
using System . Collections . Generic ;

public class SerialPortManager : MonoBehaviour
{
    public static SerialPortManager Instance ;

    void Awake ( )
    {
        Instance = this ;
    }

    SerialPort SerialPort ;

    List < int > ByteAccumulator ;

    public void Initialize ( )
    {
        ByteAccumulator = new List < int > ( ) ;
    }

    public void Connect ( string PortName , string BaudRateString , string DataBitsString , string ParityBitString , string StopBitsString )
    {
        int BaudRate = int . Parse ( BaudRateString ) ;

        int DataBits = int . Parse ( DataBitsString ) ;

        Parity ParityBit = ParityBitString == "O" ? Parity . Odd : ParityBitString == "E" ? Parity . Even : Parity . None ;

        StopBits StopBits = StopBitsString == "2" ? StopBits . Two : StopBits . One ;

        SerialPort = new SerialPort ( PortName , BaudRate , ParityBit , DataBits , StopBits ) ;

        SerialPort . ReadBufferSize = 1024 * 1024 * 4 ;

        SerialPort . Open ( ) ;
    }

    public void Disconnect ( )
    {
        SerialPort . Dispose ( ) ;

        SerialPort = null ;
    }

    public int [ ] ReadBytes ( )
    {
        ByteAccumulator . Clear ( ) ;

        while ( SerialPort . BytesToRead > 0 )
        {
            ByteAccumulator . Add ( SerialPort . ReadByte ( ) ) ;
        }

        return ( ByteAccumulator . ToArray ( ) ) ;
    }
}