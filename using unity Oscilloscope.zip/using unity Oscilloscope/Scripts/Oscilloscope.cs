﻿using UnityEngine ;
using UnityEngine . UI ;

public class Oscilloscope : MonoBehaviour
{
    public GameObject SetupContainer , ConfigurationContainer , DisplayContainer ;

    public InputField PortNameInput , BaudRateInput , DataBitsInput , ParityBitInput , StopBitsInput ;

    public InputField SampleBytesInput , MaxSampleInput , SampleBitsInput , DisplayWidthInput , DisplayHeightInput , GroupSizeInput , GroupModeInput ;

    void Start ( )
    {
        SetupContainer . SetActive ( true ) ;

        ConfigurationContainer . SetActive ( false ) ;
        
        DisplayContainer . SetActive ( false ) ;

        SerialPortManager . Instance . Initialize ( ) ;

        ByteProcessor . Instance . Initialize ( ) ;

        SampleProcessor . Instance . Initialize ( ) ;
    }

    public void HandleConnectButton ( )
    {
        SerialPortManager . Instance . Connect ( PortNameInput . text , BaudRateInput . text , DataBitsInput . text , ParityBitInput . text , StopBitsInput . text ) ;

        SetupContainer . SetActive ( false ) ;

        DisplayContainer . SetActive ( true ) ;

        HandleApplyButton ( ) ;
    }

    public void HandleDisconnectButton ( )
    {
        ConfigurationContainer . SetActive ( false ) ;

        DisplayContainer . SetActive ( false ) ;

        SerialPortManager . Instance . Disconnect ( ) ;

        SetupContainer . SetActive ( true ) ;
    }

    public void HandleApplyButton ( )
    {
        ByteProcessor . Instance . Configure ( SampleBytesInput . text , SampleBitsInput . text , MaxSampleInput . text ) ;

        SampleProcessor . Instance . Configure ( GroupSizeInput . text , GroupModeInput . text ) ;

        DisplayManager . Instance . Configure ( DisplayWidthInput . text , DisplayHeightInput . text ) ;
    }

    void HandleConfigurationToggle ( )
    {
        if ( ConfigurationContainer . activeSelf )
        {
            ConfigurationContainer . SetActive ( false ) ;
        }
        else
        {
            ConfigurationContainer . SetActive ( true ) ;

            StatusDisplayManager . Instance . Clear ( ) ;
        }
    }

    void Update ( )
    {
        if ( DisplayContainer . activeSelf )
        {
            if ( Input . GetKeyDown ( KeyCode . Space ) )
            {
                HandleConfigurationToggle ( ) ;
            }

            int [ ] BytesReceived = SerialPortManager . Instance . ReadBytes ( ) ;

            if ( BytesReceived . Length > 0 )
            {
                int ErrorCount ;

                double [ ] ActualSamplesReceived = ByteProcessor . Instance . ProcessBytes ( BytesReceived , out ErrorCount ) ;

                if ( ErrorCount > 0 && ConfigurationContainer . activeSelf )
                {
                    StatusDisplayManager . Instance . UpdateErrorCount ( ErrorCount ) ;
                }

                if ( ActualSamplesReceived . Length > 0 )
                {
                    if ( ConfigurationContainer . activeSelf )
                    {
                        StatusDisplayManager . Instance . UpdateFrequency ( ActualSamplesReceived . Length ) ;
                    }

                    double [ ] ProcessedSamples = SampleProcessor . Instance . ProcessSamples ( ActualSamplesReceived ) ;

                    if ( ProcessedSamples . Length > 0 )
                    {
                        DisplayManager . Instance . ProcessSamples ( ProcessedSamples ) ;
                    }
                }
            }
        }
    }
}