﻿using UnityEngine ;
using System . Collections . Generic ;

public class ByteProcessor : MonoBehaviour
{
    public static ByteProcessor Instance ;

    void Awake ( )
    {
        Instance = this ;
    }

    int SampleByteCount ;

    int LeadByteNullBitMask , MaxSampleInput ;

    int CurrentSampleValue , CurrentSampleByteCount ;

    List < double > SampleAccumulator ;

    public void Initialize ( )
    {
        SampleAccumulator = new List < double > ( ) ;
    }

    public void Configure ( string SampleBytesString , string SampleBitsString , string MaxSampleInputString )
    {
        SampleByteCount = int . Parse ( SampleBytesString ) ;

        LeadByteNullBitMask = 0 ;

        {
            int NullBitCount = SampleByteCount * 8 - int . Parse ( SampleBitsString ) ;

            for ( int Index = 0 ; Index < NullBitCount ; Index ++ )
            {
                LeadByteNullBitMask |= ( 1 << ( 7 - Index ) ) ;
            }
        }

        MaxSampleInput = int . Parse ( MaxSampleInputString ) ;

        CurrentSampleValue = CurrentSampleByteCount = 0 ;
    }

    public double [ ] ProcessBytes ( int [ ] Bytes , out int ErrorCount )
    {
        ErrorCount = 0 ;

        SampleAccumulator . Clear ( ) ;

        foreach ( byte CurrentByte in Bytes )
        {
            if ( CurrentSampleByteCount == 0 )
            {
                if ( ( CurrentByte & LeadByteNullBitMask ) != 0 )
                {
                    ErrorCount ++ ;
                }
                else
                {
                    CurrentSampleValue = CurrentByte ;

                    CurrentSampleByteCount = 1 ;
                }
            }
            else
            {
                CurrentSampleValue = ( CurrentSampleValue << 8 ) | CurrentByte ;

                CurrentSampleByteCount ++ ;
            }

            if ( CurrentSampleByteCount == SampleByteCount )
            {
                SampleAccumulator . Add ( ( double ) CurrentSampleValue / ( double ) MaxSampleInput ) ;

                CurrentSampleValue = CurrentSampleByteCount = 0 ;
            }
        }

        return ( SampleAccumulator . ToArray ( ) ) ;
    }
}