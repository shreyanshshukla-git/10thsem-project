﻿using UnityEngine ;
using UnityEngine . UI ;
using System ;

public class DisplayManager : MonoBehaviour
{
    public static DisplayManager Instance ;

    void Awake ( )
    {
        Instance = this ;
    }

    public RawImage DisplayTextureContainer ;

    public Toggle PausedToggle , PauseAtNextChangeToggle ;

    Texture2D DisplayTexture ;

    int Width , Height , MaximumDisplaySampleValue ;

    int CurrentSampleIndex ;

    int [ ] CurrentSamples ;

    byte [ ] DisplayTextureData ;

    bool Paused ;

    int SampleCountDuringPause ;

    int MostRecentSample ;

    public void Configure ( string DisplayWidthString , string DisplayHeightString )
    {
        if ( DisplayTexture != null )
        {
            Destroy ( DisplayTexture ) ;
        }

        Width = int . Parse ( DisplayWidthString ) ;

        Height = int . Parse ( DisplayHeightString ) ;

        MaximumDisplaySampleValue = Height - 1 ;

        DisplayTexture = new Texture2D ( Width , Height , TextureFormat . Alpha8 , false , false ) ;

        DisplayTexture . filterMode = FilterMode . Point ;

        DisplayTextureContainer . texture = DisplayTexture ;

        CurrentSampleIndex = 0 ;

        CurrentSamples = new int [ Width ] ;

        DisplayTextureData = new byte [ Width * Height ] ;

        DisplayTexture . LoadRawTextureData ( DisplayTextureData ) ;

        DisplayTexture . Apply ( ) ;

        Paused = PausedToggle . isOn = PauseAtNextChangeToggle . isOn = false ;
    }

    public void ProcessSamples ( double [ ] NewSamples )
    {
        if ( PausedToggle . isOn )
        {
            if ( ! Paused )
            {
                Paused = true ;

                SampleCountDuringPause = 0 ;
            }
        }
        else
        {
            if ( Paused )
            {
                Paused = false ;
            }
        }

        foreach ( double NewSample in NewSamples )
        {
            if ( Paused )
            {
                if ( SampleCountDuringPause == Width )
                {
                    break ;
                }

                SampleCountDuringPause ++ ;
            }

            DisplayTextureData [ Width * CurrentSamples [ CurrentSampleIndex ] + CurrentSampleIndex ] = 0 ;

            CurrentSamples [ CurrentSampleIndex ] = ( int ) Math . Round ( NewSample * MaximumDisplaySampleValue ) ;

            if ( PauseAtNextChangeToggle . isOn )
            {
                if ( CurrentSamples [ CurrentSampleIndex ] != MostRecentSample )
                {
                    PauseAtNextChangeToggle . isOn = false ;

                    PausedToggle . isOn = true ;

                    Paused = true ;

                    SampleCountDuringPause = 1 ;
                }
            }

            MostRecentSample = CurrentSamples [ CurrentSampleIndex ] ;

            DisplayTextureData [ Width * CurrentSamples [ CurrentSampleIndex ] + CurrentSampleIndex ] = 255 ;

            CurrentSampleIndex = ( CurrentSampleIndex + 1 ) % Width ;
        }

        DisplayTexture . LoadRawTextureData ( DisplayTextureData ) ;

        DisplayTexture . Apply ( ) ;
    }
}