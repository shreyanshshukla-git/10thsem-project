﻿using UnityEngine ;
using System . Collections . Generic ;

public class SampleProcessor : MonoBehaviour
{
    public static SampleProcessor Instance ;

    void Awake ( )
    {
        Instance = this ;
    }

    int GroupSize ;

    enum GroupModes
    {
        Minimum , Maximum , Mean , Median
    }

    GroupModes GroupMode ;

    List < double > InputSampleAccumulator , OutputSampleAccumulator ;

    public void Initialize ( )
    {
        InputSampleAccumulator = new List < double > ( ) ;

        OutputSampleAccumulator = new List < double > ( ) ;
    }

    public void Configure ( string GroupSizeString , string GroupModeString )
    {
        InputSampleAccumulator . Clear ( ) ;

        GroupSize = int . Parse ( GroupSizeString ) ;

        if ( GroupModeString == "MINIMUM" )
        {
            GroupMode = GroupModes . Minimum ;
        }
        else if ( GroupModeString == "MAXIMUM" )
        {
            GroupMode = GroupModes . Maximum ;
        }
        else if ( GroupModeString == "MEAN" )
        {
            GroupMode = GroupModes . Mean ;
        }
        else if ( GroupModeString == "MEDIAN" )
        {
            GroupMode = GroupModes . Median ;
        }
    }

    double CalculateMinimumSample ( )
    {
        double MinimumSample = 1 ;

        foreach ( double CurrentSample in InputSampleAccumulator )
        {
            if ( CurrentSample < MinimumSample )
            {
                MinimumSample = CurrentSample ;
            }
        }

        return ( MinimumSample ) ;
    }

    double CalculateMaximumSample ( )
    {
        double MaximumSample = 0 ;

        foreach ( double CurrentSample in InputSampleAccumulator )
        {
            if ( CurrentSample > MaximumSample )
            {
                MaximumSample = CurrentSample ;
            }
        }

        return ( MaximumSample ) ;
    }

    double CalculateMeanSample ( )
    {
        double SampleSum = 0 ;

        foreach ( double CurrentSample in InputSampleAccumulator )
        {
            SampleSum += CurrentSample ;
        }

        return ( SampleSum / InputSampleAccumulator . Count ) ;
    }

    double CalculateMedianSample ( )
    {
        InputSampleAccumulator . Sort ( ) ;

        return ( InputSampleAccumulator [ InputSampleAccumulator . Count / 2 ] ) ;
    }

    public double [ ] ProcessSamples ( double [ ] ActualSamples )
    {
        OutputSampleAccumulator . Clear ( ) ;

        foreach ( double CurrentActualSample in ActualSamples )
        {
            InputSampleAccumulator . Add ( CurrentActualSample ) ;

            if ( InputSampleAccumulator . Count == GroupSize )
            {
                if ( GroupMode == GroupModes . Minimum )
                {
                    OutputSampleAccumulator . Add ( CalculateMinimumSample ( ) ) ;
                }
                else if ( GroupMode == GroupModes . Maximum )
                {
                    OutputSampleAccumulator . Add ( CalculateMaximumSample ( ) ) ;
                }
                else if ( GroupMode == GroupModes . Mean )
                {
                    OutputSampleAccumulator . Add ( CalculateMeanSample ( ) ) ;
                }
                else if ( GroupMode == GroupModes . Median )
                {
                    OutputSampleAccumulator . Add ( CalculateMedianSample ( ) ) ;
                }

                InputSampleAccumulator . Clear ( ) ;
            }
        }

        return ( OutputSampleAccumulator . ToArray ( ) ) ;
    }
}