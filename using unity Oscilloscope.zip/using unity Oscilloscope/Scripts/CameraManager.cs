﻿using UnityEngine ;

public class CameraManager : MonoBehaviour
{
    public Camera TargetCamera ;

    const double ReferenceCameraHeight = 1080 / 2 ;

    const double ReferenceRatio = 16.0 / 9.0 ;

    double CurrentWidth , CurrentHeight ;

    void Awake ( )
    {
        CheckAndUpdate ( ) ;
    }

    void Update ( )
    {
        CheckAndUpdate ( ) ;
    }

    void CheckAndUpdate ( )
    {
        double NewWidth = Screen . width ;

        double NewHeight = Screen . height ;

        if ( NewWidth != CurrentWidth || NewHeight != CurrentHeight )
        {
            CurrentWidth = NewWidth ;

            CurrentHeight = NewHeight ;

            double NewRatio = NewWidth / NewHeight ;

            if ( NewRatio >= ReferenceRatio )
            {
                TargetCamera . orthographicSize = ( int ) ReferenceCameraHeight ;
            }
            else
            {
                double CameraHeightFactor = ReferenceRatio / NewRatio ;

                TargetCamera . orthographicSize = ( int ) ( ReferenceCameraHeight * CameraHeightFactor ) ;
            }
        }
    }
}