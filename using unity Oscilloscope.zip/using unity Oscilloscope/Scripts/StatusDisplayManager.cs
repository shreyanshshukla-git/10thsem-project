﻿using UnityEngine ;
using UnityEngine . UI ;

public class StatusDisplayManager : MonoBehaviour
{
    public static StatusDisplayManager Instance ;

    void Awake ( )
    {
        Instance = this ;
    }

    public Text ErrorCountText , FrequencyText ;

    int CurrentSecond , SampleCountDuringCurrentSecond , ErrorCount ;

    public void Clear ( )
    {
        ErrorCountText . text = FrequencyText . text = "" ;

        CurrentSecond = ( int ) Time . realtimeSinceStartup ;

        SampleCountDuringCurrentSecond = ErrorCount = 0 ;
    }

    public void UpdateErrorCount ( int NewErrorCount )
    {
        ErrorCount += NewErrorCount ;

        ErrorCountText . text = $"{ ErrorCount } errors" ;
    }

    public void UpdateFrequency ( int NewSampleCount )
    {
        int NewCurrentSecond = ( int ) Time . realtimeSinceStartup ;

        if ( NewCurrentSecond == CurrentSecond )
        {
            SampleCountDuringCurrentSecond += NewSampleCount ;
        }
        else
        {
            FrequencyText . text = $"{ SampleCountDuringCurrentSecond } Hz" ;

            SampleCountDuringCurrentSecond = NewSampleCount ;

            CurrentSecond = NewCurrentSecond ;
        }
    }
}